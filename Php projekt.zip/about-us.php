<?php
    print '
      <h1>About Us</h1>
      
      <video width="50%" controls poster="img/org123.jpg" >
        <source src="about.mp4" type="video/mp4">
        <source src="about.ogg" type="video/ogg">
          Your browser does not support HTML5 video.
    </video>
    <div style="clear: both;"></div> <br> 

    <div style="border: 0px solid black; float: left; width: 30%; margin-right: 5px">
        <figure>
            <img src="img/Klaus.jpg" img style="width:100%" alt="Klaus" title="Klaus">
            <figcaption> <i> The devil takes care of his own. </i></figcaption>
        </figure>    
    </div>

    <div style="border: 0px solid black; float: left; width: 69%;">
    

        <p> <b>Niklaus Mikaelson </b> was the main protagonist (and sometimes antagonist/anti-hero) of The Originals. <br>
            He was a former main character, antagonist/anti-hero of The Vampire Diaries. Klaus was an Original vampire and a werewolf, 
            making him the Original Hybrid.
        </p>

         <p> Klaus was the biological son of Ansel and Esther Mikaelson, the step-son of Mikael, and nephew of Dahlia. 
            Klaus is the maternal younger half-brother of Freya, Finn, Elijah, and the maternal older half-brother of Kol, Rebekah and Henrik Mikaelson.
            Klaus was the uncle of Freya and Mathias unborn son and Freya and Keelins son, Nik. Klaus is the father of hope, whose mother is Hayley,
            and the adopted father of Marcel Gerard, an orphan boy he rescued and eventually turned into a vampire. <br> <br>
            Klaus was first mentioned in the second season of The Vampire Diaries in Rose, during a conversation between Rose 
            and Stefan Salvatore. Rose warns Stefan about the Original Vampires which led to Elena Gilbert believing Klaus was the oldest vampire
            in history. Elijah later mentions that Klaus is a recluse and trusts very few people, usually only in his inner circle.
        </p>   

     <p>For over a thousand years, Klaus had been trying to break a curse placed on him. He created the myth of the sun and moon curse in 
         order to find the moonstone and the Petrova Doppelgänger, both of which were needed to break the actual curse. His goal was to liberate
        his werewolf side so he could sire his own super species of werewolf-vampire hybrids. In 1492, he finally got the chance to break his curse
        when he met Katerina Petrova, the final piece necessary to break the curse. However, Katerina managed to foil his plan to use her in the 
        sacrifice by turning into a vampire. For the next 500 years, Klaus searched for a way to break the curse without the doppelgänger, forcing
        generations of witches to help him. During his search for a way to break the curse, Klaus hunted down his family and neutralized them. He
        also hunted Katerina, who had escaped him and stolen his moonstone. However, it should also be noted that he was also on the run from his
        step-father, Mikael, as Klaus had an abusive childhood.<br>
        <hr>
    </p>
</div>

<div style="clear: both;"></div> <br> 

        <div style="border: 0px solid black; float: left; width: 69%;"> 
       
        <p> <b>Elijah Mikaelson </b> was the deuteragonist of The Originals. He was formerly a major recurring character
            in The Vampire Diaries, serving initially as an antagonist in the second season and eventually becoming a supporting character and 
            protagonist in the third season and fourth seasons. Elijah was an Original Vampire.
        </p>

         <p>Elijah was the third child and second son of Mikael and Esther. He was the younger brother of Freya and Finn, and the older brother of
            Kol, Rebekah and Henrik and the older half-brother of Klaus. He is also the uncle of Freya and Mathias. 
            daughter, Hope, and Freya and Keelins son, Nik. <br>
            Throughout his long life, Elijah had several romantic relationships. In the early 11th century, Elijah and Klaus were both in love with 
            a Petrova Doppelgänger named Tatia. Elijah accidentally killed Tatia after he became a vampire and was traumatized and horrified by the 
            violence of his actions towards her. Elijahs mother, told him to seal the event behind a "red door" and to clean himself up. As long as
            he was clean, nothing of what happened behind the red door could hurt him. As such, this became Elijahs defense mechanism to cope with 
            the horrors of his vampirism for the next thousand years. <br>
            In the 15th century, Elijah was romantically involved with another Petrova Doppelgänger, a young girl from Bulgaria, named Katerina Petrova.
            In the 19th century, Elijah was romantically involved with a witch named Céleste Dubois, whose death was later caused by his half-brother 
            Klaus. In the 21st century, Elijah rekindled his relationship with Katerina Petrova aka Katherine Pierce, before ending it to go to
            New Orleans to help Klaus. In New Orleans, Elijah has developed feelings for Hayley Marshall, after he promised to protect her and the 
            child she was carrying. Elijah respectfully kept his distance while she was married to Jackson Kenner.
         </p> <hr>
        
    </div>

    

    <div style="border: 0px solid black; float: left; width: 30%; margin-right: 5px">
        <figure>
            <img src="img/elijah.jpg" img style="width:100%" alt="Elijah" title="Elijah">
            <figcaption> <i> Carefull what you wish for. </i> </figcaption>
        </figure>    
    </div>

    <div style="clear: both;"></div> <br> 


    <div style="border: 0px solid black; float: left; width: 30%; margin-right: 5px">
        <figure>
            <img src="img/rebekah.png" img style="width:100%" alt="Rebekah" title="Rebekah">
            <figcaption> <i>Kill a demon today, face a devil tommorow. </i> </figcaption>
        </figure>    
    </div>

    <div style="border: 0px solid black; float: left; width: 69%;"> 
       
        <p> <b> Rebekah Mikaelson </b> is the former female protagonist of The Originals. She was a major recurring and guest
             character in the third, fourth and fifth seasons of The Vampire Diaries. She is the sole female Original vampire. 
        </p>

        <p>Rebekah is the second daughter of Mikael and Esther. She is the younger sister of Freya, Finn, Elijah, Kol, and the elder sister of 
            Henrik and the younger half-sister of Klaus. She is the aunt of Freya and Mathias unborn son, Klaus and Hayleys daughter, Hope, and
            Freya and Keelins son,Nik. <br> <br>
            Throughout her millennium-long life, Rebekahs actions and personality have been heavily influenced by her relationship with Klaus and
            her desire to live a normal, human life. She has also been romantically involved with a few characters from the series. In the 12th century,
            she was in love with a Vampire Hunter named Alexander who was a member of the Brotherhood of the Five. In the late 19th and early 20th
            century, she was in a relationship with Klaus protégé Marcel Gerard while she and her family lived in New Orleans. <br> <br>
            After she fled New Orleans with Klaus to escape her father Mikael, she was briefly in a relationship with Stefan Salvatore in Chicago
            during the early 1920s, and because she chose Stefan over her half-brother, Klaus daggered her for ninety years in punishment for her 
            perceived betrayal. Once she was undaggered in 2010, she had several brief flings with both Stefan and Damon Salvatore before finding 
            herself in a romantic relationship with a human, Matt Donovan. Shortly afterward, she followed her brothers Klaus and Elijah back to 
            New Orleans, where they once again settled as a family, allowing her the opportunity to rekindle her relationship with Marcel.
        </p>
            
        <p>In the middle of the first season of The Originals, she was finally given her freedom by her brother Klaus and left the city to fulfill
           her desires at a normal life. However, she returned briefly in the seasons finale to become her niece Hopes guardian after Klaus and Hayley 
           faked her death for her own safety. After her mother and brothers Finn and Kol were resurrected, Esther began tracking Rebekahs movements,
          forcing her to rejoin her family in New Orleans to plan how to best protect Hope from the new threats she faced.
    </p> 
     <hr>
    
</div>

    <div style="clear: both;"></div> <br> 

    <div style="border: 0px solid black; float: left; width: 69%;"> 
    <p> <b>Kol Mikaelson </b> is a major recurring character on The Originals. He also had a recurring role in the
         third, fourth and fifth season of The Vampire Diaries, where he served as an antagonist and anti-hero. Kol is also the main protagonist of 
         the short web series The Originals: The Awakening.
    </p>

     <p>Kol is the third son of Mikael and Esther. He is the younger brother of Freya, Finn, Elijah and older brother of Rebekah and 
         Henrik and the younger half-brother of Klaus. He is the uncle Freya and Mathias unborn son, Klaus and Hayleys daughter, Hope, and Freya
         and Keelins son, Nik. Throughout his life, Kol struggled emotionally with his status as the black sheep of the family, and the belief that
         his siblings considered him to be more of a nuisance than their own brother. He was shown to be rather spiteful and jealous over Marcel Gerard,
         whom he perceived was treated more like family than he ever was. As a result of this insecurity, Kol often lashed out violently which earned 
         him a dangerous reputation and on occasion, the ire of his siblings. In reality, his bad behavior is revealed to be simple cries for attention.
     </p> 

    <p>During the fourth season of The Vampire Diaries, Kol feared the return of Silas and was adamant about stopping him. He antagonized the Mystic 
       Falls Gang and at one point Elena Gilbert proposed a truce between them. However, the truce was really a setup to kill Kol and it ultimately 
       led to his demise at the hands of Jeremy Gilbert in A View to a Kill. In the fifth season, Kol was seen on the Other Side as it was slowly 
       collapsing due to Markos emergence. He encountered Matt Donovan and expressed fear for himself and the other supernatural beings on the Other 
       Side. Kol told Matt to warn everybody who was alive. <br> <br>
       Kol escaped the destruction of The Other Side as seen in the second season of The Originals. His mother, Esther managed to resurrect him and
       place him into the body of a young witch named Kaleb Westphall. He temporarily aided his mother and his recently resurrected brother, Finn, 
       but quickly followed his own agenda. He ended up pursuing a relationship with the young witch Davina Claire, and joined his brothers Klaus and
       Elijah, where he ultimately helped them defeat Esther and their father Mikael, once and for all. However, in retaliation for assisting his
       brothers in stopping their mother by turning her into a vampire, Finn hexed Kol with a deadly spell in Sanctuary. <hr>
    </p> 
    
</div>



<div style="border: 0px solid black; float: left; width: 30%; margin-right: 5px">
    <figure>
        <img src="img/kol.jpg" img style="width:100%" alt="Kol" title="Kol">
        <figcaption> <i> Greetings from the dead. So, who fancies a drink? </i> </figcaption>
    </figure>    
</div>

<div style="clear: both;"></div> <br> 



<div style="border: 0px solid black; float: left; width: 30%; margin-right: 5px">
    <figure>
        <img src="img/Finn.jpg" img style="width:100%" alt="Finn" title="Finn">
        <figcaption> <i>Mother made us vampires. She didnt make us monsters. We did that to ourselves. </i> </figcaption>
    </figure>    
</div>

<div style="border: 0px solid black; float: left; width: 69%;"> 
    <p> <b> Finn Mikaelson </b> iwas a major recurring character on The Originals. He served as the primary 
        antagonist for most of the second season. Finn also had a recurring role in the third season of The Vampire Diaries, where he served 
        as a minor antagonist and anti-villain.
    </p>

    <p>Finn was the first son and second child of Mikael and Esther. He was the younger brother of Freya, and the older brother of Elijah, Kol, 
        Rebekah, and Henrik and the older half-brother of Klaus. He is also the uncle of Freya and Mathias unborn son, Klaus and Hayleys daughter, 
        Hope, and Freya and Keelins son, Nik. Out of all of his siblings, Finn had the closest relationship with his mother. <br> <br> It was shown in the third 
        season of The Vampire Diaries that he was strictly loyal to his mother and believes that her intentions are the best, as he was willing to 
        sacrifice himself to kill all his younger siblings. Finns behavior and attitude were what his siblings dislike about him the most. However, 
        he eventually rekindles a relationship with his former girlfriend, Sage and had a change of heart. That reunion was unfortunately short-lived, 
        as he was killed by Matt Donovan in The Murder of One.
    </p>
        
    <p>Finn was able to escape the destruction of the Other Side as seen at the end of the first seasons finale. He was resurrected by his mother, 
        Esther, and was placed into the body of a powerful witch named Vincent Griffith. Once again, Finn worked closely with his mother, and this 
        time in an effort to get his younger siblings to take on mortal bodies. <br> <br> They all refused and were antagonized by him for the majority of the 
        second season. In Sanctuary, Finn actually put a deadly curse on his brother Kol, which killed him a few episodes later in I Love You, Goodbye.
        He also sabotaged Klauss efforts to bring peace between the vampires and the werewolves of New Orleans, by trapping both species in the The
        Abattoir, making the vampires go mad with hunger. He even tried to kill Hope, so that Dahlia wouldnt come to NOLA, almost killing Elijah in
        the process.
</p> 
    
    <p>Video link <a href="https://www.youtube.com/watch?v=GXrDYboUnnw&t=4s&ab_channel=TheOriginalsOZ" target="_blank">OVDJE</a></p>';
?>