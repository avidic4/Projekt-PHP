<?php
    print '
          <h1>Contact Form</h1>
          <div id="contact">
            <iframe src="https://maps.google.com/maps?q=1140%20Royal%20St.%20New%20Orleans&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
            <form action="http://contact.originals/pwa/responzive-page/send-contact.php" id="contact_form" name="contact_form" method="POST">
              <label for="fname">First Name *</label>
    <input type="text" id="fname" name="firstname" placeholder="Enter your name" required> <br>

    <label for="lname">Last Name *</label>
    <input type="text" id="lname" name="lastname" placeholder="Enter your last name" required> <br>

    <label for="lname">E-mail *</label>
    <input type="email" id="email" name="email" placeholder="Enter your e-mail" required> <br>

    <label for="country">Continent *<br></label>
                               <select name="country" id="country">
                                  <option value="Europe">Europe</option>
                                  <option value="Asia">Asia</option>
                                  <option value="Africa">Africa</option>
                                  <option value="Australia">Australia</option>
                                  <option value="Antarctica">Antarctica</option>
                                  <option value="North America">North America</option>
                                  <option value="South America">South America</option>

    </select> <br> <br>

    <label for="subject">Subject</label>
    <textarea id="subject" name="subject" placeholder="Write!" style="height:200px"></textarea>

    <input type="submit" value="Submit!">
  </form>
  <div style="clear: both;"></div> <hr>
                

                <div style="border: 1px solid transparent; float: left; width: 35%; margin-right: 0px">  
            
                    <form method="get" action="">
                        <table style="margin-top: 10px;border: 0px; width:60%" >
                            <thead>
                                <tr>
                                    <th colspan="5" style="border: 1px solid black"><b> Talk to your favorite actors! Win prizes! <br> </b></th>
                                </tr>
                            </thead>
                            <tbody>
                
                                <tr>
                                    <th colspan="1" style="border: 1px solid black;text-align:left">
                                    <label for="nickname"><br> Choose nickname for the game: </label>
                                    <br>
                                    <input type="text" id="nickname" name="firstandlastname"> <br> <br> </th>
                                    <th rowspan="2" colspan="4"style="border: 1px solid black;text-align:center">
                                    <label for="webpage"><br> <br> Who is your favorite character in series? </label>
                                    <br>
                                    <input type="text" id="char" name="char"> <br> <br> <br> </th>
                                </tr>
                                <tr>
                                    <th colspan="1" style="border: 1px solid black;text-align:left">
                                    <label for="favcolor"><br> Choose color! </label> <br> 
                                    <input type="color" id="favcolor" name="favcolor" value="#ff0000"> <br> <br></th>
                                
                                </tr>
                        
     
                                <tr>
                                    <td style="border: 1px solid black;text-align:center"><p><b> Best <br> Supernatural: <br> <br> </b> </p> </td>
                                    <td style="border: 1px solid black"><input type="radio" name="prvi blok" value="1"><img  src="img/vamp.ico"></td>
                                    <td style="border: 1px solid black"><input type="radio"name="prvi blok" value="2"><img  src="img/witch.ico">
                                    <td style="border: 1px solid black"><input type="radio"name="prvi blok" value="3"><img  src="img/wolf.ico"> </td>
                                </tr>
        
    
                                <tr> 
                                    <td colspan=2 style="border: 1px solid black;text-align:center"><input type="reset" value="Reset "> <br> <br></td>
                                    <td colspan=3 style="border: 1px solid black;text-align:center"><input type="submit" value="Submit "> <br> <br></td>
                                </tr>
        
                            </tbody>
                        </table>
                    </form> <br> <br>
                </div>
                <div style="clear: both;"></div> <hr>
</div>';
?>
