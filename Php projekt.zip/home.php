<?php
        print '
        <h1>Mikaelsons</h1>
      <figure>
        <img src="img/111.jpg" alt="Originals" title="Originals" img style="width:100%">
        <figcaption>"Klaus, Elijah, Rebekah, Kol, Finn - original vampires with never ending battles" </figcaption>
      </figure>
      
        <p>The Originals is The Vampire Diaries spin-off series which is produced by The CW.The twentieth episode of the 7
                        fourth season, namely called The Originals, served as a backdoor pilot. </p> 
      <p><u>Family is power. </u> <br> <br> The Original Vampire family swore it to each other a thousand years ago. 
      They pledged to remain together, always and forever.
      Now, centuries have passed and the bonds of family are broken. Time, tragedy, and hunger for power have 
     torn The Original Family apart.</p>
      <p>When Niklaus Mikaelson, the Original Vampire-Werewolf Hybrid, receives a mysterious tip that a plot is brewing against him in
      the supernatural melting pot that is known as the French Quarter of New Orleans, he returns to the city his family helped build. 
      Klaus’ questions lead him to a reunion with his diabolical former protégé, Marcel, a charismatic vampire who has total control over 
      the human and supernatural inhabitants of New Orleans. Determined to help his brother find redemption, Elijah follows Klaus and soon 
      learns that the werewolf Hayley has also come to the French Quarter searching for clues to her family history, and has fallen into the 
      hands of a powerful witch named Sophie.</p>
      <p>Tensions between the town’s supernatural factions are nearing a breaking point as Marcel commands his devoted followers and rules with
      absolute power. For Klaus, the thought of answering to his powerful protégé is unthinkable, and he vows to reclaim what was once his — the
      power, the city, and his family. While they wait to see if their sister Rebekah will leave Mystic Falls and join them, Klaus and Elijah form
      an uneasy alliance with the witches to ensure that New Orleans will be ruled by THE ORIGINALS once again.</p>
      <p>Social media:<br>
              <a href="https://www.facebook.com/cworiginals" target="_blank"><img src="img/face.jpg" img style="width:5%" alt="Facebook" title="Facebook" style="width:24px; margin-top:0.4em"></a>
              <a href="https://www.instagram.com/theoriginals/?hl=en" target="_blank"><img src="img/insta.jpg" img style="width:5%" alt="Instagram" title="Instagram" style="width:24px; margin-top:0.4em"></a>
              <a href="https://twitter.com/cworiginals?lang=en" target="_blank"><img src="img/twit.jpg" img style="width:5%" alt="Twitter" title="Twitter" style="width:24px; margin-top:0.4em"></a>
      </p>';
?>