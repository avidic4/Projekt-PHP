<?php
	define('__APP__', TRUE);
	
    session_start();
	
	include ("dbconn.php");
	
    if(isset($_GET['menu'])) { $menu   = (int)$_GET['menu']; }
	if(isset($_GET['action'])) { $action   = (int)$_GET['action']; }
	
    if(!isset($_POST['_action_']))  { $_POST['_action_'] = FALSE;  }
	
	if (!isset($menu)) { $menu = 1; }
    include_once("functions.php");
print '
<!DOCTYPE html>
<html>
  <head>
  <meta http-equiv="content-type" content="text/html" ; charset=UTF-8>
  <meta name="description" content="fantasy serija Originals">
  <meta name="keywords" content="Originals, vampires, family ">
  <meta name="author" content="Anita Vidić">
  <meta name="viewport" content="width=device-width,initial-scale=1">

  <title>My Web | Welcome</title>

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Trirong">
  <link rel="stylesheet" href="./css/style.css">
 
  </head>
  <body>
    <header>
    <div class="orig">
                <img class="mojBanner" src="img/baner.jpg" alt="Banner" style="width:100%">
      

      <nav>';
			include("menu.php");
		print '</nav>

    <main>';
    if (isset($_SESSION['message'])) {
			print $_SESSION['message'];
			unset($_SESSION['message']);
		}
    if (!isset($_GET['menu']) || $_GET['menu'] == 1) { include("home.php"); } 
	
	# News
	else if ($_GET['menu'] == 2) { include("news.php"); }
	
	# Contact
	else if ($_GET['menu'] == 3) { include("contact.php"); }
	
	# About us
	else if ($_GET['menu'] == 4) { include("about-us.php"); }

    # Gallery
    else if ($_GET['menu'] == 5) { include("gallery.php"); }

    else if ($_GET['menu'] == 6) { include("register.php"); }

    else if ($_GET['menu'] == 7) { include("signin.php"); }

    else if ($_GET['menu'] == 8) { include("admin.php"); }
    print '
      
      

    </main>
    <footer>
      <p>Copyright &copy; 2022 Anita Vidic. <a href="https://github.com/avidic4?tab=repositories"><img src="img/GitHub-Mark-32px.png"title="Github" alt="Github"></a></p>

    </footer>
    

  </body>
</html>';
?>
