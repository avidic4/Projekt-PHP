<?php
    print '
      <h1>Here are some top quotes from our favorite charachters!</h1>
      <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/1.jpg" target="blank"><img src="img/1.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Enigma </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/2.jpg" target="blank"><img src="img/2.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Desire </figcaption>
                        </figure>    
                    </div>


                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/3.jpg" target="blank"><img src="img/3.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Courage </figcaption>
                        </figure>    
                    </div>
                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/4.jpg" target="blank"><img src="img/4.jpg" img style="width:100%" alt="quote" title="quote"></a>
                            <figcaption> Persistence </figcaption>
                        </figure>    
                    </div>

                    <div style="clear: both;"> </div>



                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/7.jpg" target="blank"><img src="img/7.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Immortality </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/original.jpg" target="blank"> <img src="img/original.jpg" img style="width:100%" alt="quote" title="quote"></a> 
                            <figcaption> Braveness </figcaption>
                        </figure>    
                    </div>
                    
        
                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/maxresdefault.jpg" target="blank"><img src="img/maxresdefault.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Darkness, old friend </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/images.jpg" target="blank"><img src="img/images.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Loyalty </figcaption>
                        </figure>    
                    </div>

                    <div style="clear: both;"> </div>




                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/11.jpg" target="blank"><img src="img/11.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption>  Here comes the king  </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/10.jpg" target="blank"> <img src="img/10.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Wolf Alpha </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/14.jpg" target="blank"><img src="img/14.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Friendship above all </figcaption>
                        </figure>    
                    </div>

                    <div style="border: 0px solid black; float: left; width: 24%; margin-right: 5px">
                        <figure>
                            <a href="img/12.jpg" target="blank"><img src="img/12.jpg" img style="width:100%" alt="quote" title="quote"> </a>
                            <figcaption> Power and revenge </figcaption>
                        </figure>    
                    </div>

                    <div style="clear: both;"> </div> <br> <br> <br>
		  
			       
      </div>';
?>
